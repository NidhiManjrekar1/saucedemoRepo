export class Input {
  //All the Inputs mentioned here 
  url="https://www.saucedemo.com/"
  username= "standard_user"
  password="secret_sauce"
  lockedusername="locked_out_user"
  problematicuser="problem_user"
  glitchyuser="performance_glitch_user"
  erronioususer="error_user"
  visualissueuser="visual_user"
  unregistereduser="testuser"
  invalidpassword="test123"
  dashboardurl="https://www.saucedemo.com/inventory.html"
  maintitle="Swag Labs"
  foption1="Name (A to Z)"
  foption2="Name (Z to A)"
  foption3="Price (low to high)"
  foption4="Price (high to low)"
  productpagetitle="Products"
  product1=".inventory_item_name"
  carttitle="Your Cart"
  checkoutpagetitle="Checkout: Your Information"
  fname1="Nidhi"
  lname1="Manjrekar"
  zipcode1="560076"


  //All the locators mentioned here
  loginerrortextlocator=".error-message-container.error"
  backtoproductslocator= "#back-to-products"
  addtocartlocator="//button[@id='add-to-cart']"
  removelocator="#remove"
  cartlocator=".shopping_cart_link"
  carttitlelocator="//span[@class='title']"
  checkoutlocator="#checkout"
  checkoutpagetitlelocator=".title"
  cancellocator="#cancel"
  continuelocator="#continue"
  
  }

 
  