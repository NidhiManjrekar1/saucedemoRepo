import { Page } from '@playwright/test';
import { createWriteStream } from 'fs';

export class Checkout {
  private page: Page;

  constructor(page: Page) {
    this.page = page;
  }

   // Locators
  fnamelocator="#first-name"
  lnamelocator="#last-name"
  zipcodelocator="#postal-code"
    fname1="Nidhi"
  lname1="Manjrekar"
  zipcode1="560076"


  // Actions
  async checkoutpage(): Promise<void> {
    await this.page.fill(this.fnamelocator,this.fname1)
    await this.page.fill(this.lnamelocator,this.lname1)
    await this.page.fill(this.zipcodelocator,this.zipcode1)
  }
}