import { Page } from '@playwright/test';
import { createWriteStream } from 'fs';

export class Dashboard {
  private page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  // Locators
  titlelocator = '#user-name';
  subtitlelocator = "//span[@class='title']"
  filterlocator = '.product_sort_container';
  filteroptionlocator=".product_sort_container option"
  activefilterselection = ".active_option"
  inventoryitems= "div[class='inventory_item_name ']"

  // Actions
  async filteroption(options: string): Promise<void> {
    await this.page.click(this.filterlocator)
    await this.page.locator(this.filterlocator).selectOption(options);
  }
  // Click on product hyperlink
  async inventoryitem(item: string): Promise<void> {
    //const products = await this.page.locator(this.inventoryitems).textContent()
    await this.page.click(item)

    }

  async cartitem(product: string): Promise<void> {
    await this.page.click(product)
    
    }  
  }
 