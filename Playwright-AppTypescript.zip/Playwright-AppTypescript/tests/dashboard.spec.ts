import{test , expect} from "@playwright/test"
import { LoginPage } from '../pages/LoginPage';
import {Input} from '../pages/Input';
import { Dashboard } from "../pages/Dashboard";
import {Checkout} from "../pages/Checkout"

const input = new Input();


test.beforeEach('Login with valid credentials', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await loginPage.navigateTo(input.url);
  await loginPage.login(input.username, input.password);
});

test('Validate Page Title', async ({ page }) => {
  const dashboard = new Dashboard(page);
  const gettitle = await page.title()
  await expect(page).toHaveTitle(input.maintitle);

});

test('Validate Page Sub Title to be Products', async ({ page }) => {
  const dashboard = new Dashboard(page);
  await expect(page.locator(dashboard.subtitlelocator)).toHaveText(input.productpagetitle)

});


test('Validate option "Name (A to Z)" and validate if screen refreshes accordingly ', async ({ page }) => {
  const dashboard = new Dashboard(page);
  const list1 = await page.locator(dashboard.filterlocator).textContent()
  await expect(list1).toContain(input.foption1)
  //function call from dashboard class
  await dashboard.filteroption(input.foption1);
});


test('Validate option "Name (Z to A)" and validate if screen refreshes accordingly ', async ({ page }) => {
  const dashboard = new Dashboard(page);
  const list1 = await page.locator(dashboard.filterlocator).textContent()
  await expect(list1).toContain(input.foption2)
  //function call from dashboard class
  await dashboard.filteroption(input.foption2);
  //expect(page.locator(dashboard.activefilterselection).textContent()).toContain(input.foption2)
});

test('Validate option "Price (high to low)" and validate if screen refreshes accordingly ', async ({ page }) => {
  const dashboard = new Dashboard(page);
  const list1 = await page.locator(dashboard.filterlocator).textContent()
  await expect(list1).toContain(input.foption3)
  await dashboard.filteroption(input.foption3);
  
});

test('Validate option "Price (low to high)" and validate if screen refreshes accordingly ', async ({ page }) => {
  const dashboard = new Dashboard(page);
  const list1 = await page.locator(dashboard.filterlocator).textContent()
  await expect(list1).toContain(input.foption4)
  await dashboard.filteroption(input.foption4);
  
});

test('Validate upon clicking on any product if user is moved to productpage', async ({ page }) => {
  const dashboard = new Dashboard(page);
  //const list1 = await page.locator(dashboard.filterlocator).textContent()
  await dashboard.inventoryitem(input.product1);
  await expect(page.locator(input.backtoproductslocator)).toBeVisible()
});

test('Validate upon clicking on add to cart if remove button is enabled ', async ({ page }) => {
  const dashboard = new Dashboard(page);
  //function call from dashboard class
  await dashboard.inventoryitem(input.product1);
  await page.click(input.addtocartlocator);
  await expect(page.locator(input.removelocator)).toBeVisible()
  
});

test('Validate upon clicking on cart if user is moved to cart page', async ({ page }) => {
  const dashboard = new Dashboard(page);
  //function call from dashboard class
  await dashboard.inventoryitem(input.product1);
  await page.click(input.addtocartlocator);
  await page.click(input.cartlocator)
  await expect(page.locator(input.carttitlelocator)).toContainText(input.carttitle)
  
});

//positive scenario
test('Validate upon clicking on checkout if user is moved to checkout page', async ({ page }) => {
  const dashboard = new Dashboard(page);
  //function call from dashboard class
  await dashboard.inventoryitem(input.product1);
  await page.click(input.addtocartlocator);
  await page.click(input.cartlocator);
  await page.click(input.checkoutlocator);
  await page.click(input.checkoutpagetitlelocator);
  await expect(page.locator(input.checkoutpagetitlelocator)).toContainText(input.checkoutpagetitle)
  
});

//negative scenario
test('Validate if user cancels in checkout page, user is moved back to cart page', async ({ page }) => {
  const dashboard = new Dashboard(page);
  //function call from dashboard class
  await dashboard.inventoryitem(input.product1);
  await page.click(input.addtocartlocator);
  await page.click(input.cartlocator);
  await page.click(input.checkoutlocator);
  await page.click(input.cancellocator)
  await expect(page.locator(input.carttitlelocator)).toContainText(input.carttitle)
  
});
//positive scenario
test.only('Validate if user clicks on continue in checkout page, ', async ({ page }) => {
  const dashboard = new Dashboard(page);
  const checkout =new Checkout(page);
  await dashboard.inventoryitem(input.product1);
  await page.click(input.addtocartlocator);
  await page.click(input.cartlocator);
  await page.click(input.checkoutlocator);
  //function call from checkout class
  await checkout.checkoutpage()
  await page.click(input.continuelocator)
  
});

