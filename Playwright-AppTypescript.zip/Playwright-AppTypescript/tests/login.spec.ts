import{test , expect} from "@playwright/test"
import { LoginPage } from '../pages/LoginPage';
import {Input} from '../pages/Input';

const input = new Input();


test('Login with valid credentials', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await loginPage.navigateTo(input.url);
  await loginPage.login(input.username, input.password);

  // Adding assertions to verify url after logging in
  await expect(page).toHaveURL('https://www.saucedemo.com/inventory.html');
});

test('Login with invalid credentials', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await loginPage.navigateTo(input.url);
  await loginPage.login(input.unregistereduser, input.invalidpassword);

  // Adding assertions to verify error text
  await expect(page.locator(input.loginerrortextlocator)).toHaveText('Epic sadface: Username and password do not match any user in this service');
});

test('Login with just username and password as blank', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await loginPage.navigateTo(input.url);
  await loginPage.login(input.username,"");

  // Adding assertions to verify error text
  await expect(page.locator(input.loginerrortextlocator)).toHaveText('Epic sadface: Password is required');
});

test.only('Login with blank/empty username and password', async ({ page }) => {
  const loginPage = new LoginPage(page);

  await loginPage.navigateTo(input.url);
  await loginPage.login("","");

  // Adding assertions to verify error text
  await expect(page.locator(input.loginerrortextlocator)).toHaveText('Epic sadface: Username is required');
});
